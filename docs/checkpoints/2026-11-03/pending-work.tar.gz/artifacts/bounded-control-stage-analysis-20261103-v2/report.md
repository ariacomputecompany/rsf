# Instrumented STAGE observation v2

This is analysis of the root executor's completed Darwin development run, not a baseline pass, Linux qualification, or a production optimization result. The analyst did not execute Cargo, Fozzy, a native test, or Git. The original workload was `cargo test --locked -p rsf-vsr -p rsf-rpc -p rsf-protocol`, with its original concurrency, deadlines, retries, fixture payloads, and assertions. One supervisory Python process captured the actual child output directly into files and returned its exit status.

## Terminal evidence

The actual Cargo exit is **101**. Protocol reports **57 passed** in 6.09 s; RPC reports **129 passed, 9 failed** in 134.91 s. There is no completed VSR result in this Cargo invocation: do not count a VSR pass from the command's package list. The corrected managed-learner custody regression is among the passing RPC tests. Six all-voter publication fixtures fail at setup STAGE, one accepted-input fixture fails its positive STAGE, one control-recovery test fails quorum establishment, and one acceptance reply-loss fixture panics on an ordinary deadline-expired response write before its intended assertion completes.

Fozzy phase exits are doctor 0, strict 0, host 1, trace verify 0, replay 1, and local trace parity (`fozzy ci`) 0. The successful verification/parity phases do not override Cargo's failure. Doctor/strict use the scripted supervisor response; the host phase runs the actual Cargo child. Replay observes the recorded failed run rather than independently rerunning native scheduling. No hosted CI/CD was used.

`execution.json` records unchanged source `45d4135ab002c9634226d3228103bbe52d837914aa2624156440e0724c45e5b3` and unchanged control files. `analyze.py` independently checked the two terminal JSON records, exact child command, raw file lengths/hashes, and the trace's single `proc_spawn` child record/exit. Input hashes:

| File in observation-v2 | SHA-256 |
| --- | --- |
| execution.json | `785c4dfc1dbe01c02be45d51e14bb63291ab08fcb8797ffa4c53f2ca03807b2f` |
| cargo-process.json | `48384e58579c0c554247c82e052c58aea9763bdb7b5cca5b91f2de5392deb03c` |
| cargo.stdout | `39e98e99bb498c922517b28008a9b38f4e3c4fd67f6fb950d98712aab9a3df01` |
| cargo.stderr | `4259f1d9472b49e8ab94c4159ec460ffa611b72eed6b12d62bee95359f19b788` |
| trace.fozzy | `bf1f6f121e1d4727cd783d7aaff3f3c8ba7f56120818509aec349c5761de2004` |

## Major observation limitation

The original helper formats `writeln!` directly into stderr. Its lock serializes threads within one process, but many child processes share the descriptor and interleave formatting fragments. The parser accepts **29,762 syntactically complete records** and rejects **27,351 diagnostic-containing lines**, including 25,037 without one complete leading marker. It obtains only 8,764 begin/end pairs; 3,451 otherwise complete end records lack matching begins. A parseable record is not cryptographically framed: subtle fragment corruption that happens to satisfy the field grammar cannot be universally excluded. The concrete observations below were also read in raw stderr with their path/process context.

The parser does not reconstruct fragments, fabricate missing durations, or assign a partial line to the nearest process. `events.jsonl` and `spans.jsonl` retain original line numbers and byte offsets; `rejected-records.jsonl` records discarded line locations/reasons. `summary.json` includes mechanical aggregate distributions, but they are a biased subset of concurrent mixed workloads and must not be treated as representative performance percentiles.

None of the six failed publication STAGE exchanges has both complete client/server reversed TCP tuples in the conservative parsed set. Thus this run **cannot provide the requested complete exchange → attempt → TCP tuple → authenticated connection → phase timeline** for those failures. Exact root-labelled target phases remain useful individually. A local Node 1 stage for the same fixture is not evidence about its failing remote Node 2/3 phase.

## Failed publication fixtures

All roots below begin `/var/folders/xn/zb2_wvj508d9vx1cr7grpzlm0000gn/T/rsf-peer-native-membership-publication-7183-` and end `-0`. Full paths and raw event anchors are in `failed-stage-correlations.json`. Parent PID is 7183. Client thread identity is bound by that thread's exact local-stage root; target PID is reported only where an exact target-stage root survives. All opcode 32 references are actual MEMBERSHIP_STAGE requests.

| Root timestamp suffix; failing target | Client identity and complete observations | Actual target evidence and gaps |
| --- | --- | --- |
| `1793754582339540000`; Node 2 | Thread 475, exchange 2353; attempt 1 TLS 1.851 ms (line 39641); attempt 2 867.534 ms, WouldBlock (40644–40645). Outer assertion 1.800447667 s. | No intact target-root record identifies Node 2's process. The intact 484.134 ms source copy, 282.002 ms selected copy, and 117.895 ms seal are **Node 1 local work**, excluded from target attribution. |
| `1793754583291096000`; Node 2 | Thread 486, exchange 2377; attempt 2 TimedOut (41092); duration record missing. Outer assertion 1.997689333 s. | PID 20624, thread 2: source readback 44.087 ms (40743), closed renewal 0.102 ms (40624). No complete dispatch/response correlation. |
| `1793754582752673000`; Node 2 | Thread 478, exchange 2385; attempt 1 connect 0.121 ms (40389), frame read 682.609 ms / err (40795), whole attempt 824.809 ms / err (40804); attempt 2 WouldBlock (41188). Outer assertion 1.787660584 s. | PID 20469, thread 2: retain-anchor 0.113 ms (40740), META write 0.088 ms (41065). These do not explain the missing larger factory intervals. |
| `1793754581309675000`; Node 3 | Thread 469, exchange 2411; attempt 2 TLS 774.521 ms (41850), frame write 0.010 ms / err (41890), whole attempt 855.482 ms / TimedOut (41907–41908). Outer assertion 1.786769458 s. Node 2 previously returned a real report after 1.644333917 s. | PID 20124, thread 2: **learner factory 923.418 ms / ok** (41737); nested seal 40.001 ms (41736), META directory sync 5.663 ms (41735), META write 1.037 ms (41721). This actual target factory exceeded one 800 ms attempt's budget. Missing connection and earlier phase records prevent assigning all of that duration to a particular client attempt or proving why retry TLS waited. |
| `1793754592209051000`; Node 3 | Thread 506, exchange 2749; attempt 1 TLS 1.805 ms, frame write 0.025 ms, frame read 683.461 ms / WouldBlock, whole attempt 803.212 ms / WouldBlock (49080,49129,49567–49570). Attempt 2 connect 0.159 ms and whole attempt 907.822 ms / WouldBlock (49573,50030–50031). Outer assertion 1.797150375 s. Node 2 previously returned a real report after 1.463513 s. | PID 23254, thread 2: **source copy 401.223 ms / ok** (49565), exact membership-3/staging path. No intact full factory or authenticated dispatch interval. A superficially plausible receipt record with `root=.../stagingphase=` was rejected, not repaired. |
| `1793754597781950000`; Node 2 | Thread 512, exchange 2753; attempt 1 connect 0.128 ms and TLS 1.776 ms, then WouldBlock; attempt 2 connect 0.139 ms and whole attempt 886.344 ms / WouldBlock (49042,49079,49586,49600,50039–50040). Outer assertion 1.74186125 s. | PID 24647, thread 2 identified by exact target root. A closed-renewal end at 49726 measures 0.131 ms. Earlier `copy.*` records are setup work unless independently located inside the desired STAGE; they are not substituted for its missing source/selected copy intervals. |

The long second-attempt TLS followed by failed frame write in the groups fixture establishes that this attempt failed before successfully sending its STAGE frame. The serial receiver loop can queue a new connection behind earlier work, but v2 lacks the connection records needed to prove that queueing caused this TLS duration. This remains an inference to investigate, not a measured causal attribution.

## Other failures and scope

The accepted-input fixture root is `rsf-peer-accepted-stage-import-7183-1793754576648671000-0`. Its positive `stage_membership` fails at `retained.rs:220`; earlier requests intentionally test invalid old sender, conflicting chosen input, and foreign proposal. Do not classify those expected refusals as the failing positive request. PID 20936 / thread 2 has an intact `input.factory` end of 349.141 ms at its exact membership-2/staging root (stderr 23185), followed by retained-prefix read 0.519 ms (23190). Parent thread 458 has a final observed opcode-32 exchange 1566 attempt 1 lasting 879.944 ms / err (23203), but missing request/connection records prevent an exact positive-request correlation or complete retry sequence.

The control-recovery failure is an actual `QuorumUnavailable` during setup: Node 1 refused the connection, Node 2 expired the deadline. The reply-loss acceptance fixture's worker panics on `write_frame(...).unwrap()` at membership_decision.rs:411; its caller then fails promise quorum at line 435. These failures do not establish that the deliberately lost ACCEPT reply or later recovery safety assertion failed. Their full original error text is retained in `failure-sections.txt`; this analysis proposes no test weakening.

## Next measured step

Before splitting production work further, repeat the unchanged workload with each helper constructing one finite complete line and issuing one `write_all` call. This directly addresses the observed fragmented logging and reduces formatting/syscall overhead. It does not guarantee cross-process atomicity on every descriptor, remove observer cost, or authorize accepting malformed records; preserve rejection counts and exact source/formatter identities.

If cleaner records reproduce target factory/source-copy dominance, the next narrow measurement is the existing `input.factory` boundary versus group append, source immutable readback/replay, selected copy, META publication, callbacks, and INSTALLED publication on the **same exact failed target connection**. Only if that remains coarse should actual storage factory/name barriers be timed individually. `VsrMembershipStagedPlan` already caches ID/recovered state; this run does not justify adding a proof cache or changing custody validation.

All quoted durations are wall time. `copy.group` includes packing/canonical encoding, checksum/encoding, writes, rotations and synchronization. `input.factory` includes its existing setup/durability operations. Synchronous diagnostic writes, scheduler delays, lock waits, filesystem work and CPU work are not separated. Even measured individual `sync_all` durations include scheduling. Nested durations are not additive independent samples, and an end's elapsed time excludes its own end-line write but includes inner observations. The instrumented RPC runtime and additional deadline failures indicate material perturbation relative to earlier observations; this is not a controlled estimate of logging overhead or a demonstrated new product regression. No production patch, deadline/retry change, payload reduction or isolated passing-fixture claim follows from v2.

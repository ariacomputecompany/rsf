# STAGE observation v3: actual failed target connection

The root executor's completed diagnostic still fails: actual Cargo exit **101**, protocol **57 passed** (5.77 s), RPC **137 passed / 1 failed** (98.07 s). The failing case is `replication::tests::membership_publication::startup_validation::real_tls_strict_cold_open_reuses_validated_inputs_without_rejecting_published_b_ancestry`, at its original all-voter fixture STAGE setup. No completed VSR result is present. This is neither a passing rerun nor Linux production qualification; all earlier failures remain preserved.

Source is unchanged within this run at `4034396bea0b2bd406f4536a47c25d2741edd9b9f58b27b7840285c980ac0e89`. The original Cargo workload, concurrency, 800 ms attempt deadlines, existing retry, fixture payload, and assertions remain intact. The only diagnostic change from v2 preformats each log line before one `write_all`, reducing fragment-level output. Fozzy exits remain doctor 0 / strict 0 / host 1 / verify 0 / replay 1 / local parity 0. Successful trace verification/parity do not override the child failure. No hosted CI/CD was used.

The analyst executed only static log parsing, not Cargo/Fozzy/native tests/Git. The parser independently verified terminal process JSON equality, command, output hashes/lengths, and the trace's exact child record/exit. It accepts 74,436 records and rejects 188 diagnostic-containing lines (all missing one complete leading marker), with 33,215 paired spans and 47 unmatched complete ends. The improved format does not justify accepting remaining garbled records or treating logs as an unperturbed benchmark.

## Exact correlation

The full root is `/var/folders/xn/zb2_wvj508d9vx1cr7grpzlm0000gn/T/rsf-peer-native-membership-publication-48544-1793754876347804000-0`. The assertion reports Node 2 STAGE failure after **1.641643625 s**, `Resource temporarily unavailable (os error 35)`.

Parent PID **48544**, thread **583**, exchange **3795**, local Node **1** → remote Node **2**, opcode **32**:

- Attempt 1 socket is **127.0.0.1:50957 → 127.0.0.1:50250** (stderr line 70306). The exact reversed server tuple at line 70304 belongs to PID **67788**, thread **2**, connection **47**.
- That connection completes server TLS (3.403 ms, line 70312) and request read (0.113 ms, 70314), then starts an **authenticated sender 1, local 2, opcode 32** dispatch at 70315. Its stage root is exactly `membership-2/staging` under the failed fixture.
- Client attempt 1 connects in 0.124 ms, TLS in 2.982 ms, writes its frame in 0.032 ms, then waits 794.690 ms in frame read and returns WouldBlock. Whole attempt: **820.739 ms** (70303–70552).
- Attempt 2 connects in 0.194 ms using **127.0.0.1:50970 → 127.0.0.1:50250** (70556). TLS waits **778.466 ms**, then returns WouldBlock; whole attempt **809.435 ms** (70553–70857). There is no successful frame write or authenticated second dispatch in the capture.

The original receiver loop handles connections serially. Its first authenticated STAGE remains active while the client's retry attempts TLS. This source-backed interpretation now has the exact first socket/connection and a complete target phase sequence, unlike v2. The second connection's accept/TLS event is not present, so the capture does not claim a measured server queue duration or a second STAGE execution.

## Measured target phases

All durations below come from the actual Node 2 PID/thread after connection 47's dispatch begins. Values are elapsed wall time, not CPU time. Nested rows must not be added to their parents.

| Actual phase | Wall time | Raw stderr end line |
| --- | ---: | ---: |
| cached receipt check | 0.002 ms | 70318 |
| authority from retained decision | 79.059 ms | 70320 |
| load chosen stage, total | **1480.849 ms** | 70844 |
| initialize decision (inside load) | 0.136 ms | 70323 |
| retain chosen (inside load) | 55.232 ms | 70345 |
| select plan (inside load) | 4.840 ms | 70347 |
| voter stage factory (inside load) | **1407.541 ms** | 70842 |
| source copy (inside factory) | **870.383 ms** | 70639 |
| input factory (inside source copy) | **760.508 ms** | 70558 |
| retained-prefix read (inside source copy) | 0.496 ms | 70560 |
| original store capture / closed renewal (source) | 0.082 / 0.103 ms | 70562 / 70564 |
| actual source group append (inside source copy) | 96.081 ms | 70638 |
| source immutable readback | 42.836 ms | 70724 |
| selected copy (inside factory) | **364.848 ms** | 70757 |
| original store capture / closed renewal (selected) | 0.090 / 0.133 ms | 70752 / 70754 |
| actual selected group append (inside selected copy) | 48.119 ms | 70756 |
| selected immutable readback | 14.198 ms | 70759 |
| META seal (inside factory) | 77.779 ms | 70837 |
| META write / actual file sync | 0.105 / 31.659 ms | 70771 / 70792 |
| META rename / directory-open-and-sync | 0.145 / 19.622 ms | 70806 / 70835 |
| committed-entry extraction | 0.029 ms | 70852 |

The first client read expires while the target is inside `input.factory` (begin 70352; end 70558), before any source group append starts (70565). Thus optimizing that group's encoding alone could not explain or remove this observed first-attempt overrun. The selected-copy aggregate is also much longer than its group's measured duration. This identifies **factory/setup/publication boundaries** as the next useful narrow observation; it does not establish that directory sync, CPU, or any individual syscall dominates.

After the factory/load completes, `stage.materialize` starts (70846), committed entries are extracted, and `stage.callbacks` starts (70853). No callback end, materialization end, INSTALLED receipt, authenticated-dispatch end, or response-write event follows for PID 67788. The test then reports the second timeout and its `PublicationPeer` teardown kills/waits the child. These unclosed spans have no measured completion duration; there is no evidence of an ACK, successful materialization, or a lost successful STAGE reply in this failure.

## Next temporary measurement and limits

Instrument only the measured source/selected factory boundaries next: input route creation, initial root/inputs barriers, descriptor encode/read and exact write/sync/rename, descriptor-directory barrier, `SegmentStore::open_with_options`, the existing child-to-parent input-publication barriers, selected route check and `SegmentStore::open_recovered`. Reuse the full-line helper, keep one call/result/order for every operation, and keep descriptor publication before record-store creation. No barrier elimination/coalescing, format change, proof cache, extra retry, timeout increase, or workload reduction is justified yet. No storage-wide observer framework or per-record logging is needed.

The paired nested phase wall times include inner diagnostic writes, synchronization waits, scheduling, allocation/encoding, and filesystem work. `copy.group` is not an isolated fsync measurement. Individual sync wall time still includes scheduling. End-line emission occurs after elapsed-time capture. The changed formatter and differing failed tests/runtime are not a controlled causal estimate of observer cost. This remains one instrumented concurrent Darwin sample with material observer overhead and no absolute cross-process timestamp; Linux VM qualification remains separate.

All raw input hashes and accepted/rejected records are retained in `summary.json`, `failed-stage-correlations.json`, and `manifest.json`. Key input SHA-256 values: execution `338cb34cbd7784e94a9c16cfc0a2d03f7de736809a51deff8a342bf4141d28a6`; Cargo process `012a6f94b554d694844f600f9548f41e8ae095911564684b649d3e824fe2b47d`; stdout `754ae5957b5f6c8bfede8a8d2a165f78f8d6866c3e4e86946e1381e8e8b677d0`; stderr `c4b2face63c221b267985b61cb81ee1dcc4c456c6d589b6216b7d808164ff5c9`; trace `e03267de1dd3adebd34a68f8c773b2afb315b5171706386499ac83d05192871f`.

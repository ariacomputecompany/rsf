"""Static source/patch inventory only; no compiler, Git, or runtime invocation."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT.parent / "bounded-prefix-discard-development"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tree(name):
    folder = ROOT / name
    return {str(p.relative_to(folder)): p.read_bytes() for p in folder.rglob("*") if p.is_file()}


# Reuse only our already reviewed pure static hunk/body helpers, before their
# packaging entry point. Bind those helper source bytes in the evidence.
helpers = {"__file__": str(UPSTREAM / "package.py")}
exec((UPSTREAM / "package.py").read_text().split('base = tree("base")')[0], helpers)
patch = helpers["patch"]
functions = helpers["functions"]
reconstruction = {"__file__": str(ROOT / "reconstruct-static-context.py")}
exec((UPSTREAM / "reconstruct.py").read_text().split('base = tree("base")')[0], reconstruction)
apply = reconstruction["apply"]

base = tree("base")
proposed = tree("proposed")
declared = json.loads((ROOT / "base-manifest.json").read_text())
assert len(base) == 136
assert {p: sha(data) for p, data in base.items()} == declared["files"]
namespace = "crates/rsf-vsr/src/learner/prefix/namespace.rs"
observation = "crates/rsf-vsr/src/learner/prefix/namespace/observation.rs"
parent = "crates/rsf-vsr/src/learner/prefix/tests.rs"
tests = "crates/rsf-vsr/src/learner/prefix/tests/discard_caller.rs"
changed = {p for p in base.keys() | proposed.keys() if base.get(p) != proposed.get(p)}
assert changed == {namespace, observation, parent, tests}
assert proposed[parent] == base[parent] + b"\n#[cfg(unix)]\nmod discard_caller;\n"
# Precisely limit the only non-test source-file delta to a cfg(test) event and
# its equivalent Result return spelling. No hidden authority/action path.
expected = base[namespace].replace(
    b"        original.validate()?;\n        self.candidates.insert(id, candidate);\n        self.validate(owner)\n",
    b"        original.validate()?;\n        self.candidates.insert(id, candidate);\n        self.validate(owner)?;\n        #[cfg(test)]\n        observation::at(Operation::CandidateReady, true, &owner.directory(&id))?;\n        Ok(())\n",
).replace(
    b"pub(in crate::learner::prefix) enum Operation {\n",
    b"pub(in crate::learner::prefix) enum Operation {\n    #[cfg(test)]\n    CandidateReady,\n",
)
assert proposed[namespace] == expected
observed = dict(base)
for p in [namespace, observation]:
    observed[p] = proposed[p]
routes = {
    "integration.patch": (base, proposed),
    "observation.patch": (base, observed),
    "tests.patch": (observed, proposed),
}
patches = {}
for name, (before, after) in routes.items():
    data = patch(before, after)
    (ROOT / name).write_bytes(data)
    patches[name] = {"sha256": sha(data), "bytes": len(data)}
combined, _ = apply(base, "integration.patch")
observed_again, _ = apply(base, "observation.patch")
split, _ = apply(observed_again, "tests.patch")
assert combined == proposed == split
assert observed_again == observed
for label, files in [("combined", combined), ("observation", observed), ("split", split)]:
    for p, data in files.items():
        out = ROOT / "static-reconstruction" / label / p
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
required = []
for name, body in functions(proposed[tests]).items():
    required.append({"name": "learner::prefix::tests::discard_caller::" + name,
                     "body_sha256": sha(body), "kind": "preservation_caller_composition",
                     "requires_new_test_seam": True})
assert len(required) == 3
preserved = []
for path, data in base.items():
    if not path.startswith("crates/rsf-vsr/src/learner/prefix/") or not path.endswith(".rs"):
        continue
    current = functions(proposed[path])
    for name, body in functions(data).items():
        assert current[name] == body
        preserved.append({"path": path, "name": name, "body_sha256": sha(body)})
manifest = {
    "scope": "Separate artifact-only test companion. No production behavior, initial rebase, compilation, Git, or runtime qualification.",
    "base_manifest_sha256": sha((ROOT / "base-manifest.json").read_bytes()),
    "base_files": len(base), "final_files": len(proposed),
    "patches": patches,
    "files": [{"path": p, "base_sha256": sha(base[p]) if p in base else None,
               "proposed_sha256": sha(proposed[p]), "kind": "test_only"} for p in sorted(changed)],
    "new_test_bodies": len(required), "preserved_prefix_bodies": len(preserved),
    "static_reconstruction": {"direct_exact": True, "observation_then_tests_exact": True},
    "helper_sources": {str(UPSTREAM / name): sha((UPSTREAM / name).read_bytes()) for name in ["package.py", "reconstruct.py"]},
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(ROOT / "required-tests.json").write_text(json.dumps({"scope": "Source names only; compiled --list is root-owned.", "tests": required}, indent=2) + "\n")
(ROOT / "preserved-tests.json").write_text(json.dumps({"tests": preserved}, indent=2) + "\n")
print(json.dumps({"changed_files": len(changed), "new_tests": len(required), "preserved_prefix_bodies": len(preserved), "patches": patches}, indent=2))

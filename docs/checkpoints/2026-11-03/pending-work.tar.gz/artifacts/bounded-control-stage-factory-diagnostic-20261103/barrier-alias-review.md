# Refinement: preserve the resolved directory route for final-file aliases

This read-only refinement preserves the earlier barrier-review/v4 evidence unchanged. It supersedes the earlier unconditional assertion that final active-file publication always covers the resolved store-directory ancestors. No candidate source was edited or executed here.

The generic store permits a final active segment symlink: `SegmentLog::recover_file` uses ordinary existing-file open (`lib.rs:325`), while manifest decoding enforces a canonical plain segment filename (`store.rs:962`). A provisioned directory alias and a separate final-file alias can route differently:

```
logical/store -> physical/deep/store
physical/deep/store/segments/<canonical-active> -> foreign/deep/log
```

The original first `create_dir_all_synced(logical/store/segments)` traverses resolved `physical/deep/store/segments` ancestors and lexical `logical/store/segments` ancestors. The later `sync_file_publication` resolves the **file**, so its physical route starts at `foreign/deep`; its other route is lexical `logical/store/segments`. These paths do not necessarily visit `physical/deep`. Trusted, durably provisioned alias topology is still required, but it is not a reason to silently drop the existing explicit resolved store-directory renewal guarantee.

The smallest conservative refinement is the parent's proposed branch: keep ordinary initial mkdir; after decoding/creating the manifest, inspect the canonical active path with `symlink_metadata`. If its final component is a symlink, renew the full segments-directory routes **before recovery**, retaining the former early publication boundary for this uncommon alias case. Propagate metadata failures as recovery errors and never initialize a missing referenced file. Do not reject historically supported generic aliases or canonicalize them into a different caller path. Standalone SegmentLog and durable-directory helper behavior remains untouched.

For a non-symlink final component, the decoder's exact plain filename plus the unchanged-namespace contract makes the file's canonical parent equal the resolved segments directory. Thus the normal existing-store final publication covers the intended directory route without a new capability/cache abstraction. Fresh initialization cannot legitimately create its initial segment through a preexisting final-name alias: `create_new` and the nonempty-manifestless rejection preserve that boundary.

Required regression uses actual producer bytes, not a fabricated manifest: create a real store, append a WAL record, close it, move its canonical active bytes to a distinct physical subtree, install the trusted final-file alias and a separate directory alias, and renew fixture alias setup explicitly. Through the real public store open, observe the resolved store ancestor omitted by the naive candidate, plus the final file's physical and lexical publication routes. Require exact recovered WAL/target bytes and preserved aliases. Inject return-path uncertainty **after a real directory sync** at the resolved store ancestor: no returned owner, no recovery mutation before this alias fallback completes, original locks released, and valid cold retry/append. This is a route/custody observation and injected uncertainty test, not a machine-power-loss reproduction.

The ordinary fresh/existing route budget remains 2N/N only for the no-final-file-alias fixture. The alias branch intentionally retains another full directory route; tests must not force the ordinary budget onto it. The shared observation format and fault scope must distinguish this branch from the normal torn-tail case, where repair may precede the final publication failure as documented earlier.

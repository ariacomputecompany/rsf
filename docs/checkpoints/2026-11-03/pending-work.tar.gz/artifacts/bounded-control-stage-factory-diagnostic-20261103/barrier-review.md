# Source-only publication barrier review

This analysis was prepared while v4 was active. It makes no v4 outcome or timing claim and contains no implementation. Root alone owns source changes and execution. The inspected paths are the current storage generic open/recovery/publication code and the VSR factory with the reviewed diagnostic overlay. Linux remains the production target; current Darwin observations are development evidence.

## Strongest small candidate: defer the first storage open route barrier

Root proposed changing only `SegmentStore::open_recovered`'s first `create_dir_all_synced(root/segments)` to ordinary `fs::create_dir_all(root/segments)`, with the same error mapping. Static source review supports this smaller change over introducing a publication-proof/cache API. It removes one redundant full ancestor traversal from each successful open while retaining existing branch-specific durability. This is a candidate for root review and actual failure/regression testing, not an implemented or qualified result.

Current order in `crates/rsf-storage/src/store.rs:131`:

1. Create and fully publish `root/segments` and both trusted resolved/lexical ancestor routes.
2. Acquire process gate and MANIFEST lock. `SegmentLock::acquire` (`lib.rs:465`) only mkdirs its parent and creates/acquires its sidecar; it does **not** independently publish directory custody.
3. Read/create manifest. In the missing-manifest branch (`store.rs:1048`), sync the store parent, fully publish `root/segments` again, reject nonempty manifestless segment residue, create+sync initial segment and segments directory, then write+sync+rename manifest and sync root.
4. Recover existing manifest-referenced segments.
5. Open the active segment/sidecar, then `SegmentLog::open_locked_with_publication` (`lib.rs:146`) performs the complete file-name publication route before returning the writer.
6. Build cursor from metadata and return writer plus recovered records.

There is no public writer or recovery result between steps 1 and 6. The proposed change does not delete steps 3 or 5.

### Missing manifest

The unchanged missing-manifest branch renews the complete directory route **before** any new initial segment or manifest is created. Ordinary mkdir at step 1 can leave only the same recognizable visible empty directories/lock sidecar if the later route barrier fails. The initial segment still crosses file sync → segments-directory sync before the manifest can reference it; the manifest still crosses file sync → rename → store-root sync. Its final active writable open still publishes the segment/sidecar names and all ancestor links before return. No acknowledged factory can escape after just a visible descriptor or manifest.

Manifestless nonempty residue remains rejected without rewriting that residue. Existing `read_or_create_manifest` is also used by public `recover` and `recover_or_quarantine`; their own `create_dir_all_synced(root)` and their branch behavior must remain unchanged in this narrow candidate.

### Existing manifest

`read_or_create_manifest` only decodes it. `recover_manifest_with_handler(..., None)` (`store.rs:1107`) reads existing segment files with `create=false`; only the active segment is permitted torn-tail truncation. It does not initialize missing referenced data or invoke quarantine. The final `SegmentLog` writable-open publication traverses the actual physical and lexical parent routes, covering all names created by sidecar acquisition, before either the writer or returned recovery escapes. Visible names from an interrupted earlier attempt are therefore still renewed, rather than treated as proof of publication.

There is one **observable failure-order change to document and test**: an existing active torn tail can be repaired/synced by recovery before a later ancestor-publication failure, whereas the old first barrier could fail before that repair. Generic recovery already permits repairing an unacknowledged active suffix; complete committed/accepted records must remain unchanged. No writer, recovered result, or ACK may escape when the later publication fails. The change must not be represented as a strict read-only open. Strict bounded/no-repair constructors are separate and are not changed by this candidate.

Generic multi-handle coordination still uses the same gate and same lock acquisition. Standalone `SegmentLog::open`, its create-capable `recover`, and the public durable-directory helper must keep their complete retry barriers. No cross-operation successful-open memory, timestamp inference, global cache, or newly public authority object is necessary.

## Other repeated work: not proposed for removal now

The VSR input factory still publishes its canonical descriptor **before** records-store initialization. Initial root/inputs barriers and descriptor file sync → rename → input-directory sync are not merged into a later data-store barrier here. The final five-path `sync_input_publication` follows the storage active-file publication and often repeats the same directories in the same operation, but also revalidates the route. Removing that helper wholesale would remove validation, and recognizing equivalent physical routes needs an explicit unchanged-namespace proof. Leave it unchanged for the small candidate.

The fresh storage branch's parent sync also repeats a parent already traversed by its current callers. That observation is not permission to delete branch-local safeguards independently: retain that branch intact while changing the single earlier unconditional full barrier, so the branch continues to own its complete factory boundary.

The three full storage routes are real duplicated work, not work in `SegmentLock` (which is plain exclusion). The resolved `/private/var/...` and lexical `/var/...` routes in Darwin can also visit the same physical directory twice. However a blanket per-inode "already synced" set is not justified across arbitrary allowed routes. Existing `inner/../leaf` support can make the lexical ancestor walk visit a physical parent, then another child, then that parent again; removing the later parent barrier solely because its inode appeared earlier can discard an ordering edge. No generic route collapse or ancestor deduplication is proposed.

## Meaningful qualification before adopting the small candidate

- Actual fresh owner: retain all factory crash-prefix and manifestless-residue tests; prove initial segment file/segments barrier precede manifest publication and that no writer escapes a failed publication.
- Actual existing owner: append a real complete WAL record and a partial unacknowledged active suffix, fail the final route publication after recovery, require Err/no owner and exact complete-prefix preservation, allow only the permitted partial-tail repair, restore the failure and reopen/append successfully. Label injected syscall-boundary failures honestly; they are not machine-power-loss simulation.
- Existing-name retry: fail a final publication after names are visible, then repeat the public open and prove the actual full route barrier is retried. Do not substitute an existence check.
- Preserve the current standalone segment/new-file, public create-capable recovery, ordinary strict-read zero-barrier, relative/ParentDir and trusted-alias route tests. Existing `recovery_publication_tests` require real writable publication but do not establish exact per-open work bounds.
- A narrowly observed barrier-count/order test should show exactly one former unconditional traversal removed while the actual missing-manifest/final-file barriers remain, without modifying record/sync policy or weakening a fault oracle.
- Root must run the original full-concurrency STAGE workload after the product candidate and after removing temporary instrumentation. An instrumented isolated pass, one faster sample, or a reduced deadline workload is insufficient.

No production modification follows solely from this source proof. V4 should first establish the actual measured distribution between directory barriers, store open, source read/encoding and group copy; total wall time is not CPU or I/O attribution.

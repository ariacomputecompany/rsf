# STAGE factory observation v4

The root executor's complete diagnostic passes: actual Cargo exit **0**, protocol **57 passed** (6.12 s), RPC **138 passed** (110.71 s), VSR **289 passed** (151.62 s), and three zero-test doc-test groups. All six Fozzy phases return 0. Source and control files remain unchanged within the run at `61ce08a516cc1ced91d2ab7c3684ea1451ac523fc136c142c129f2669900ca75`. The original full-concurrency workload, 800 ms attempt deadlines, existing retry, all-voter fixture reports, and payloads are unchanged.

This is an **instrumented development observation, not a timeout fix or Linux qualification**. No product semantics were changed between v3 and v4; only more phase observations were added. Prior failed runs remain evidence. The analyst ran only read-only parsing/reconstruction, not Cargo/Fozzy/native runtime or Git. There was no hosted CI/CD.

`analyze.py` independently verified actual child command/exit, terminal JSON equality, raw output lengths/hashes, and the trace's single recorded child outcome. It accepts 205,165 complete records, rejects 373 diagnostic-containing lines, and pairs 98,362 spans. Raw line/byte anchors and rejected records remain in the package. The 128 intact paired remote opcode-32 dispatches include **20 longer than 800 ms**. Thus a terminal pass still includes actual first-attempt STAGE deadlines and successful existing retries.

## Named-test attribution limit

The v3 failing test `real_tls_strict_cold_open_reuses_validated_inputs_without_rejecting_published_b_ancestry` passes at `cargo.stdout:201`. Its successful root announcement is libtest-captured and withheld; diagnostic records expose process/thread IDs but not test names, and `Ready::drop` removes successful roots. Consequently no v4 root below is falsely assigned that test name by ordinal, ThreadId, or timestamp proximity. The exact remote roots/connections below are independently correlated; they support factory attribution without pretending a same-test paired benchmark.

## Slowest complete actual remote STAGEs

All sockets are loopback and are bound by exact reversed client/server tuples, followed by authenticated sender/local/opcode fields. Main RPC test PID is 80267. All three receivers use thread 2. Full records for every paired dispatch are in `remote-stage-correlations.json`.

| Actual root / target | First request and actual receiver | Existing retry outcome |
| --- | --- | --- |
| `rsf-peer-accepted-stage-import-80267-1793755669725816000-0/membership-2/staging` | Client thread391/exchange1330, source3→target2, `52533→52472`; PID88603 connection15. Dispatch **1454.617 ms** (stderr26215–27662), first response errors (27664). Client first attempt808.537ms/err. | Client retry `52545→52472`, connection16; dispatch1.338ms, response0.020ms/ok (27681–27683); whole retry658.133ms/ok. This is accepted-input import, not the all-voter publication fixture. |
| `rsf-peer-native-membership-publication-80267-1793755693979287000-0/membership-2/staging` | Client thread483/exchange2323, source1→target2, `53569→52734`; PID92723 connection48. Dispatch **988.887 ms** (60383–62110), response TimedOut after0.045ms (62117–62121); client first802.742ms/err. | Client `53601→52734`, connection49. Cached dispatch6.384ms and response0.025ms/ok (62206–62210), whole retry235.857ms/ok. |
| Same publication root, `membership-3/staging` | Client thread483/exchange2473, source1→target3, `53726→52753`; PID92832 connection43. Dispatch **955.729 ms** (65589–67244), response TimedOut after0.044ms (67255–67257); client first804.156ms/err. | Client `53751→52753`, connection44. Cached dispatch3.190ms and response0.081ms/ok (67312–67315), whole retry190.364ms/ok. |

These successful first dispatches finish materialization/receipt after their first client attempt has expired; the first response write fails, and the original retry receives the cached result. This is actual retry behavior, unlike v3's killed receiver with incomplete callbacks. No retry was added by the diagnostic.

## Factory measurements on the correlated all-voter Node 2

These values belong to PID92723/connection48 at its exact target root. Timings are wall time; parent/child rows are nested and must not be summed as independent work.

| Phase | Wall time | stderr end line |
| --- | ---: | ---: |
| authority decision / retain chosen / select plan | 68.336 / 45.980 / 5.591 ms | 60516 / 60653 / 60669 |
| stage root publication / owner | 51.532 / 0.111 ms | 60805 / 60818 |
| input factory | **308.102 ms** | 61299 |
| input route / preflight | 2.720 / 0.046 ms | 60839 / 60878 |
| descriptor encode / read | 0.015 / 0.010 ms | 60880 / 60882 |
| descriptor create / write / file sync / rename | 3.227 / 0.044 / 5.639 / 3.017 ms | 60884 / 60886 / 60892 / 60895 |
| records `SegmentStore::open_with_options` | **220.464 ms** | 61211 |
| final input publication aggregate | 49.718 ms | 61296 |
| source group / source copy total | 69.962 / 390.067 ms | 61470 / 61478 |
| source immutable readback | 42.342 ms | 61566 |
| selected `SegmentStore::open_recovered` | **213.566 ms** | 61780 |
| selected retained decode | 0.011 ms | 61793 |
| selected group / selected copy total | 37.314 / 261.231 ms | 61898 / 61899 |
| selected immutable readback / META seal | 14.131 / 21.186 ms | 61908 / 61987 |
| stage factory / load chosen | 797.692 / 861.609 ms | 61995 / 62000 |
| application callbacks / INSTALLED receipt / materialize | 18.873 / 23.224 / 49.967 ms | 62050 / 62088 / 62104 |

The source descriptor read is the expected missing-file branch for a new factory; its diagnostic `result=err` does not mean factory failure. Descriptor publication remains before records open. The explicitly timed directory `sync_all`s are: initial stage root4.237ms, inputs2.845ms, descriptor input-directory5.582ms; final child-to-parent segments3.682ms → records6.115ms → input4.086ms → inputs4.082ms → stage root11.557ms (60857–61293). Directory opens are separate. Nested observation, checks, scheduling and other glue explain why the aggregate is not the sum of just these syscall durations.

The same fixture's learner Node3 has records store open240.356ms and selected open185.342ms within input factory318.685ms and total stage factory768.989ms (66402,66918,66487,67056). Its descriptor encode17µs/write2.592ms/file-sync6.649ms and final input publication35.789ms are separately observed. The slowest accepted-input case also performs decision-input import before stage creation: retain-chosen554.103ms, its decision records open196.559ms, then stage records open240.692ms and selected open160.458ms. These are distinct stores with distinct obligations, not proof that one copy may be discarded.

## Narrow recommendation

The measurements support qualification of the **single initial storage-open barrier removal**, not broad barrier coalescing. Both actual records and selected opens occupy substantial target wall time; source review locates a repeated full ancestor traversal within each. There is no measurement isolating each internal traversal, so do not claim that removing one saves one third of these times, resolves every deadline, or identifies all time as filesystem latency.

The source proof is `../bounded-control-stage-factory-diagnostic-20261103/barrier-review.md`: change only the initial `open_recovered` synced mkdir to plain mkdir. Fresh missing-manifest initialization still completes its full route before initial segment/manifest publication. Existing-manifest recovery still passes the final active `SegmentLog` full name/ancestor publication before returning a writer or recovery result. Keep descriptor-before-records, file/manifest sync ordering, standalone helpers, public recovery paths and five VSR child-to-parent barriers unchanged. No global cache or new proof API is required.

Required regressions must exercise the public store opener itself. Derive actual lexical/resolved route length N for the fixture rather than hardcoding host depth: fresh open loses only one full traversal (3N→2N), existing open 2N→N. Verify actual WAL append and cold byte/chain equality. A private test-only observer **after real successful directory sync** can inject return-path uncertainty: first fresh route observes no MANIFEST, final route observes actual manifest/segment; each injected boundary returns no writer, releases actual locks, and permits a valid cold retry. This is not an injected kernel fsync failure or power-loss simulation. Include existing torn-tail repair before late publication failure as an explicit permitted failure-order change: complete prefix exact, only unacknowledged tail repair, no writer/ACK. Preserve generic alias/ParentDir and recovery tests; do not deduplicate arbitrary physical inode visits across lexical parent-component orderings.

Root must compile/test that separate product candidate, remove temporary instrumentation and run the original concurrent suites/full baseline. A single instrumented pass, this proposed work bound, or a faster isolated sample is insufficient. The observed durations include logging, scheduling, locks, allocation, encoding and filesystem work; no CPU/I/O causal decomposition or Linux qualification follows.

Input SHA-256: execution `a42f25b9ba82d3140aad6cf492979163605a8b18608d8c25abd2f053581a0ebb`; Cargo process `1c7d74e0defbb3f5a6dd3b7083c062495d929410013e30d50034a54928a77c0a`; stdout `6407503b2e1482743f5f2255ef5c3cd0562882e9a22ec8304e4c66b3ae1f242c`; stderr `3ef77ca0610b39df2d9054b965c846e10734c988de6ce9464bc210020d3acaa7`; trace `9e1380617db6c56881c95cfd21bed9113ce5b1de214b2d8d7b6982ece4d94aa8`. Exact analysis outputs are bound in `manifest.json`.
